package com.alejo.consultas.dao;

import com.alejo.consultas.models.Receta;

public interface IRecetaDao {

    Receta registrarReceta(Receta receta);

}
