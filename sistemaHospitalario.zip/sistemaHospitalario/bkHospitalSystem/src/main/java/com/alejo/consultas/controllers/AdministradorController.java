package com.alejo.consultas.controllers;

import java.util.List;

import com.alejo.consultas.dao.ICitaDao;
import com.alejo.consultas.models.Cita;
import com.alejo.consultas.models.CitaCancelada;
import com.alejo.consultas.dao.IConsultorioDao;
import com.alejo.consultas.models.Consultorio;
import com.alejo.consultas.dao.IMedicoDao;
import com.alejo.consultas.models.Medico;
import com.alejo.consultas.dao.IPacienteDao;
import com.alejo.consultas.models.Paciente;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdministradorController {

    @Autowired
    ICitaDao citaDao;

    @RequestMapping(value = "administrador/agendarCita", method = RequestMethod.POST)
    public void crearConsultorio(@RequestBody Cita cita) {
        citaDao.registrar(cita);
    }

    @RequestMapping(value = "administrador/cargarCitas")
    public List<Cita> cargarCitas() {

        List<Cita> listaCitas = citaDao.obtenerCitas();
        return listaCitas;
    }

    @RequestMapping(value = "administrador/cancelarCita", method = RequestMethod.DELETE)
    public void eliminarCita(@RequestBody CitaCancelada citaCancelada) {

        long idCita = citaCancelada.getCita();

        citaDao.eliminarCita(idCita);

        citaDao.registrarCitaEliminada(citaCancelada);

    }

    @Autowired
    IConsultorioDao consultorioDao;

    @RequestMapping(value = "administrador/crearConsultorio", method = RequestMethod.POST)
    public void crearConsultorio(@RequestBody Consultorio consultorio) {
        consultorioDao.registrar(consultorio);
    }

    @RequestMapping(value = "administrador/cargarConsultorios")
    public List<Consultorio> cargarConsultorios() {

        List<Consultorio> listaMedicos = consultorioDao.obtenerConsultorios();
        return listaMedicos;
    }

    @RequestMapping(value = "administrador/consultorio/{id}")
    public Consultorio getConsultorio(@PathVariable long id) {
        Consultorio consultorio = consultorioDao.buscarConsultorio(id);
        return consultorio;
    }

    @Autowired
    IMedicoDao medicoDao;

    @RequestMapping(value = "administrador/crearMedico", method = RequestMethod.POST)
    public void crearMedico(@RequestBody Medico medico) {
        medicoDao.registrar(medico);
    }

    @RequestMapping(value = "administrador/cargarMedicos")
    public List<Medico> cargarMedicos() {

        List<Medico> listaMedicos = medicoDao.obtenerMedicos();
        return listaMedicos;
    }

    @RequestMapping(value = "administrador/medico/{id}")
    public Medico getMedico(@PathVariable long id) {
        Medico medico = medicoDao.buscarMedico(id);
        return medico;
    }

    @Autowired
    IPacienteDao pacienteDao;

    @RequestMapping(value = "administrador/crearPaciente", method = RequestMethod.POST)
    public void crearPaciente(@RequestBody Paciente paciente) {
        pacienteDao.registrar(paciente);
    }

    @RequestMapping(value = "administrador/cargarPacientes")
    public List<Paciente> cargarPacientes() {

        List<Paciente> listaPacientes = pacienteDao.obtenerPacientes();
        return listaPacientes;
    }

    @RequestMapping(value = "administrador/paciente/{id}")
    public Paciente getPaciente(@PathVariable long id) {
        Paciente paciente = pacienteDao.buscarPaciente(id);
        return paciente;
    }

    @RequestMapping(value = "administrador/actualizarPaciente", method = RequestMethod.PUT)
    public void actualizarPaciente(@RequestBody Paciente paciente) {

        pacienteDao.actualizarPaciente(paciente);

    }

    

}
