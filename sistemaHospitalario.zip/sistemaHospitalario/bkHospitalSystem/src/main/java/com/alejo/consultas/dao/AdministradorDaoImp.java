package com.alejo.consultas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.alejo.consultas.models.Administrador;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class AdministradorDaoImp implements IAdministradorDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Administrador> validarAdministrador(Administrador administrador) {

        String query = "FROM Administrador WHERE email = :email";

        List<Administrador> lista = entityManager.createQuery(query).setParameter("email", administrador.getEmail())
                .getResultList();

        if (!lista.isEmpty()) {
            if (administrador.getPassword().equals(lista.get(0).getPassword())) {

                System.out.println("clave correcta!");

                return lista;

            } else {
                System.out.println("clave incorrecta!");
            }
        }

        return null;
    }

}
