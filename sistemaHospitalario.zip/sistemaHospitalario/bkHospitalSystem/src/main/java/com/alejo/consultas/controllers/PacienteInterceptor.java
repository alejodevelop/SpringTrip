package com.alejo.consultas.controllers;

public class PacienteInterceptor {
    
}
