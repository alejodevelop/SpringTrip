package com.alejo.consultas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.alejo.consultas.models.Cita;
import com.alejo.consultas.models.CitaCancelada;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class CitaDaoImp implements ICitaDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrar(Cita cita) {
        entityManager.merge(cita);
    }

    @Override
    public List<Cita> obtenerCitas() {
        String query = "FROM Cita";
        List<Cita> listaCitas = entityManager.createQuery(query).getResultList();
        return listaCitas;
    }

    @Override
    public Cita eliminarCita(long id) {
        Cita cita = entityManager.find(Cita.class, id);
        entityManager.remove(cita);
        return cita;
    }

    @Override
    public void registrarCitaEliminada(CitaCancelada citaCancelada) {
        entityManager.merge(citaCancelada);

    }

}
