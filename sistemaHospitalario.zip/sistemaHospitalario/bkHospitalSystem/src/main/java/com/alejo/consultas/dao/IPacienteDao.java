package com.alejo.consultas.dao;

import java.util.List;

import com.alejo.consultas.models.Paciente;

public interface IPacienteDao {

    void registrar(Paciente paciente);

    List<Paciente> obtenerPacientes();

    Paciente buscarPaciente(Long id);

    void actualizarPaciente(Paciente paciente);

    List<Paciente> validarPaciente(Paciente paciente);

}
