package com.alejo.consultas.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.alejo.consultas.models.Receta;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class RecetaDaoImp implements IRecetaDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Receta registrarReceta(Receta receta) {
        return entityManager.merge(receta);
    }

}
