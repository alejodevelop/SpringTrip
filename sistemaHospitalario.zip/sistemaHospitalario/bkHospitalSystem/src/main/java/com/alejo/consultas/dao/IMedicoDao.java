package com.alejo.consultas.dao;

import java.util.List;

import com.alejo.consultas.models.Medico;

public interface IMedicoDao {

    void registrar(Medico medico);

    List<Medico> obtenerMedicos();

    Medico buscarMedico(long id);

    List<Medico> validarMedico(Medico medico);

}
