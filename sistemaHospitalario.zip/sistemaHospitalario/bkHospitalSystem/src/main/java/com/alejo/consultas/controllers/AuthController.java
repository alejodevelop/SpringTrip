package com.alejo.consultas.controllers;

import java.util.List;

import com.alejo.consultas.dao.IAdministradorDao;
import com.alejo.consultas.dao.IMedicoDao;
import com.alejo.consultas.dao.IPacienteDao;
import com.alejo.consultas.models.Administrador;
import com.alejo.consultas.models.Medico;
import com.alejo.consultas.models.Paciente;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {

    @Autowired
    IAdministradorDao AdministradorDao;

    @RequestMapping(value = "auth/admin", method = RequestMethod.POST)
    public String loginAdministrador(@RequestBody Administrador administrador) {

        List<Administrador> respuestaValidacion = AdministradorDao.validarAdministrador(administrador);

        return "falta generar el token man";
    }

    @Autowired
    IMedicoDao medicoDao;

    @RequestMapping(value = "auth/doctor", method = RequestMethod.POST)
    public List<Medico> loginMedico(@RequestBody Medico medico) {

        System.out.println("Peticion doctor recibida!");

        List<Medico> respuestaValidacion = medicoDao.validarMedico(medico);

        return respuestaValidacion;
    }

    @Autowired
    IPacienteDao pacienteDao;

    @RequestMapping(value = "auth/patient", method = RequestMethod.POST)
    public List<Paciente> loginPaciente(@RequestBody Paciente paciente) {

        System.out.println("Peticion patient recibida!");

        List<Paciente> respuestaValidacion = pacienteDao.validarPaciente(paciente);

        return respuestaValidacion;
    }

}
