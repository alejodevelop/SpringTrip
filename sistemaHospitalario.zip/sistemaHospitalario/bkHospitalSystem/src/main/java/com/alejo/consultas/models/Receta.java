package com.alejo.consultas.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "recetas")
public class Receta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    @Setter
    @Column(name = "id")
    private long id;

    @Getter
    @Setter
    @Column(name = "cita")
    private long cita;

    @Getter
    @Setter
    @Column(name = "acetaminofen")
    private int acetaminofen;

    @Getter
    @Setter
    @Column(name = "diclofenaco")
    private int diclofenaco;

    @Getter
    @Setter
    @Column(name = "ibuprofeno")
    private int ibuprofeno;

    @Getter
    @Setter
    @Column(name = "naproxeno")
    private int naproxeno;

}
