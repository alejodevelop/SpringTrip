

function iniciarSesion() {

    var perfil = document.getElementById("perfiles").value;
    console.log(perfil);

    if (perfil == "administrador") {
        loginAdministrador();
    }
    if (perfil == "medico") {
        loginMedico();
    }
    if (perfil == "paciente") {
        loginPaciente();
    }




}

async function loginAdministrador() {

    let datos = {};

    datos.email = document.getElementById("txtEmail").value;
    datos.password = document.getElementById("txtPassword").value;


    const request = await fetch('loginAdministrador', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    });

    const listaAdministradores = await request.json();

    console.log(listaAdministradores);

    if (Object.keys(listaAdministradores).length === 0) {
        alert("Error al iniciar sesion, vuelve a intentarlo!")
    } else {
        location.href = "vistaAdministrador.html";
    }


}


async function loginMedico() {


    let datos = {};

    datos.email = document.getElementById("txtEmail").value;
    datos.password = document.getElementById("txtPassword").value;


    const request = await fetch('loginMedico', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    });

    const listaMedicos = await request.json();

    console.log(listaMedicos);

    if (Object.keys(listaMedicos).length === 0) {
        alert("Error al iniciar sesion, vuelve a intentarlo!")
    } else {
        location.href = "vistaMedico.html";
    }

}

async function loginPaciente() {

    let datos = {};

    datos.email = document.getElementById("txtEmail").value;
    datos.password = document.getElementById("txtPassword").value;


    const request = await fetch('loginPaciente', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    });

    const listaPacientes = await request.json();

    console.log(listaPacientes);

    if (Object.keys(listaPacientes).length === 0) {
        alert("Error al iniciar sesion, vuelve a intentarlo!")
    } else {
        location.href = "vistaPaciente.html";
    }


}