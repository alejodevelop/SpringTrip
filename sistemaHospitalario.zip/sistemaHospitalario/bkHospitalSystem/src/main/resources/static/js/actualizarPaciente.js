document.addEventListener('DOMContentLoaded', function () {
    listarPacientes();
}, false);

async function listar(ruta) {
    const request = await fetch(ruta, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}

datos = {};


function obtenerRadioPaciente(e) {

    datos.id = e.id;

}


async function listarPacientes() {

    const listaPacientes = await listar('administrador/cargarPacientes');

    console.log(listaPacientes);

    let html = '';

    for (let paciente of listaPacientes) {
        let items = '<input type="radio" onChange="obtenerRadioPaciente(this)" id=' +
            paciente.id + ' name="paciente">' +
            '<label for= ' + paciente.id + ' > ' + paciente.nombre + '  ' +
            paciente.apellido + '  ' + paciente.email + '  ' + paciente.direccion + '  ' +
            paciente.telefono + '</label > <br>';

        html += items;
    }

    document.getElementById('listaPacientes').outerHTML = html;
}



async function actualizarTelefonoDireccion() {

    datos.telefono = document.getElementById("txtTelefono").value;
    datos.direccion = document.getElementById("txtDireccion").value;
    datos.email = "";
    datos.password = "";
    datos.nombre = "";
    datos.apellido = "";


    const request = await fetch('administrador/actualizarPaciente', {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    });

    location.reload();

}

