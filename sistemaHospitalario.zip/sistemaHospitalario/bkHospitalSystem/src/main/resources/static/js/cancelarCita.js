document.addEventListener('DOMContentLoaded', function () {
    listarCitas();
}, false);

datos = {};

async function listar(ruta) {
    const request = await fetch(ruta, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}

async function listarCitas() {

    const listaCitas = await listar('administrador/cargarCitas');


    let html = '';

    //implementar despues 
    //buscar paciente
    //buscar medico
    //buscar consultorio

    for (let cita of listaCitas) {

        paciente = await buscarRegistro(cita.paciente, "paciente");
        medico = await buscarRegistro(cita.medico, "medico");
        consultorio = await buscarRegistro(cita.consultorio, "consultorio");


        let items = '<input type="radio" onChange="obtenerRadioCita(this)" id=' +
            cita.id + ' name="cita">' +
            '<label for= ' + cita.id + ' > ' + paciente.nombre + '  ' +
            medico.nombre + '  ' + consultorio.direccion + '</label > <br>';

        html += items;
    }

    document.getElementById('listaCitas').outerHTML = html;

}

function obtenerRadioCita(e) {

    datos.cita = e.id;

}

async function buscarRegistro(dato, donde) {
    const request = await fetch("administrador/" + donde + "/" + dato, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}

async function cancelarCita() {

    if (!confirm("Desea cancelar la cita?")) {
        return;
    }

    datos.justificacion = document.getElementById("txtJustificacion").value;

    console.log(datos.justificacion);
    console.log(datos.Cita);

    const request = await fetch("administrador/cancelarCita", {
        method: 'DELETE',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos),
    });
    location.reload();
}