// js puro y duro
document.addEventListener('DOMContentLoaded', function () {
    listarMedicos();
    listarPacientes();
    listarCitas();
}, false);

// window.onload = listarMedicos;

async function listar(ruta) {
    const request = await fetch(ruta, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}


async function listarMedicos() {

    const listaMedicos = await listar('administrador/cargarMedicos');

    console.log(listaMedicos);

    let html = '';

    for (let medico of listaMedicos) {
        let items = '<span id=' + medico.id + ' name="medico">' +
            medico.id + '  ' + medico.nombre + '  ' +
            medico.apellido + '  ' + medico.email + '  ' + '</span> <br>';

        html += items;
    }

    document.getElementById('listaMedicos').outerHTML = html;

}



async function listarPacientes() {

    const listaPacientes = await listar('administrador/cargarPacientes');

    console.log(listaPacientes);

    let html = '';

    for (let paciente of listaPacientes) {
        let items = '<span id=' + paciente.id + ' name="paciente">' +
            paciente.id + '  ' + paciente.nombre + '  ' +
            paciente.apellido + '  ' + paciente.email + '  ' + paciente.direccion + '  ' +
            paciente.telefono + '</span > <br>';

        html += items;
    }

    document.getElementById('listaPacientes').outerHTML = html;
}

//dato puede ser, medico, paciente, cita
async function buscarRegistro(dato, donde) {
    const request = await fetch("administrador/" + donde + "/" + dato, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}

async function listarCitas() {

    const listaCitas = await listar('administrador/cargarCitas');


    let html = '';

    //implementar despues 
    //buscar paciente
    //buscar medico
    //buscar consultorio

    for (let cita of listaCitas) {

        paciente = await buscarRegistro(cita.paciente, "paciente");
        medico = await buscarRegistro(cita.medico, "medico");
        consultorio = await buscarRegistro(cita.consultorio, "consultorio");


        let items = '<span id=' + cita.id + ' name="cita">' +
            paciente.nombre + '  ' + medico.nombre + '  ' +
            consultorio.direccion + '  ' + cita.horario + '  ' + '</span> <br>';

        html += items;
    }

    document.getElementById('listaCitas').outerHTML = html;

}


