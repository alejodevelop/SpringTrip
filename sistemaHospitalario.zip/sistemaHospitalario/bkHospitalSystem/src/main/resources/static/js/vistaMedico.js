document.addEventListener('DOMContentLoaded', function () {
    listarCitas();
}, false);


datosReceta = {
    cita: 0,
    acetaminofen: 0,
    diclofenaco: 0,
    ibuprofeno: 0,
    naproxeno: 0,
}

datosDiagnostico = {};



function obtenerRadioCita(e) {

    datosReceta.cita = e.id;
    datosDiagnostico.cita = e.id;

}

function obtenerCheckMedicamentos() {
    cbMedicamentos = document.getElementsByName("cbMedicamento");
    cbnMedicamentos = document.getElementsByName("nMedicamento");


    for (let i = 0; i < cbMedicamentos.length; i++) {
        if (cbMedicamentos[i].checked) {
            if (cbMedicamentos[i].id == "acetaminofen") {
                datosReceta.acetaminofen = cbnMedicamentos[i].value;
            }
            if (cbMedicamentos[i].id == "diclofenaco") {
                datosReceta.diclofenaco = cbnMedicamentos[i].value;
            }
            if (cbMedicamentos[i].id == "ibuprofeno") {
                datosReceta.ibuprofeno = cbnMedicamentos[i].value;
            }
            if (cbMedicamentos[i].id == "naproxeno") {
                datosReceta.naproxeno = cbnMedicamentos[i].value;
            }
        }

    }
}

async function listar(ruta) {
    const request = await fetch(ruta, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}

async function listarCitas() {

    const listaCitas = await listar('administrador/cargarCitas');

    console.log(listaCitas);

    let html = '';

    for (let cita of listaCitas) {
        let radioButtons = '<input type="radio" onChange="obtenerRadioCita(this)" id=' + cita.id + ' name="paciente">' +
            '<label for= ' + cita.id + ' > ' + cita.paciente + '  ' +
            cita.medico + '  ' + cita.consultorio + '  ' + cita.horario +
            '</label > <br>';

        html += radioButtons;
    }

    document.getElementById('listaPacientes').outerHTML = html;


}

async function buscarRegistro(dato, donde) {
    const request = await fetch(donde + "/" + dato, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}

async function crearReceta() {
    await obtenerCheckMedicamentos();


    const requestReceta = await fetch("crearReceta", {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datosReceta),
    });

    receta = await requestReceta.json();

    datosDiagnostico.receta = receta.id;

}

// datosDiagnostico.id = 12;
// datosDiagnostico.diagnostico = "vivo";
// datosDiagnostico.receta = 0;
// datosDiagnostico.cita = 1;

async function crearDiagnostico() {


    datosDiagnostico.diagnostico = document.getElementById("txtDiagnostico").value;


    const requestReceta = await fetch("crearDiagnostico", {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datosDiagnostico),
    });
}



