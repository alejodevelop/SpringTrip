import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ServerRequestsService {

  constructor(private http: HttpClient) {

  }

  getAuth(requestURL: string, molde: any) {
    // , { responseType: 'text' }



    const response = this.http.post(requestURL, molde, { responseType: 'text' }).subscribe(
      (resp: any) => {

        console.log(JSON.stringify(resp));

        if (resp != null) {

          localStorage.setItem('token', resp);

        }


      },
      (err: any) => {

        console.log(JSON.stringify(err));


      }
    );


  }

}
