import { Component, OnInit } from '@angular/core';
import { ServerRequestsService } from 'src/app/services/server-requests.service';
import { Router } from '@angular/router';
import { admin } from 'src/app/interfaces/admin';
import { doctor } from 'src/app/interfaces/doctor';
import { patient } from 'src/app/interfaces/patient';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  private href: string = "";
  private admin: admin;
  private doctor: doctor;
  private patient: patient;
  public email: string;
  public password: string;

  constructor(
    private request: ServerRequestsService,
    private router: Router
  ) {

    this.href = this.router.url;
    this.email = "";
    this.password = "";

    this.admin = {
      id: 0,
      email: "",
      password: "",
      nombre: "",
      apellido: ""
    }

    this.doctor = {
      id: 0,
      email: "",
      password: "",
      nombre: "",
      apellido: ""
    }

    this.patient = {
      id: 0,
      email: "",
      password: "",
      nombre: "",
      apellido: "",
      telefono: "",
      direccion: ""
    }
  }

  ngOnInit(): void {
  }

  login(): void {


    if (this.href == "/login/admin") {
      this.admin.email = this.email;
      this.admin.password = this.password;
      this.request.getAuth("http://localhost:8080/auth/admin", this.admin);
    }

    if (this.href == "/login/doctor") {
      this.doctor.email = this.email;
      this.doctor.password = this.password;
      this.request.getAuth("http://localhost:8080/auth/doctor", this.doctor);
    }

    if (this.href == "/login/patient") {
      this.patient.email = this.email;
      this.patient.password = this.password;
      this.request.getAuth("http://localhost:8080/auth/patient", this.patient);
    }





  }

}
