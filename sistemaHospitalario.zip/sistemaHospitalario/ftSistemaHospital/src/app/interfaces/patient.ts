export interface patient {
    id: number,
    email: string,
    password: string,
    nombre: string,
    apellido: string,
    telefono: string,
    direccion: string
}