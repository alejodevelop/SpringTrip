export interface admin {
    id: number,
    email: string,
    password: string,
    nombre: string,
    apellido: string
}