export interface doctor {
    id: number,
    email: string,
    password: string,
    nombre: string,
    apellido: string
}