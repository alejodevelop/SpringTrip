export interface Keyable {
    [Key: string]: any
}