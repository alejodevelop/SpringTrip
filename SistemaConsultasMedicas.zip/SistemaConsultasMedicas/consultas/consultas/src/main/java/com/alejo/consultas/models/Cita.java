package com.alejo.consultas.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "citas")
public class Cita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    @Setter
    @Column(name = "id")
    private long id;

    @Getter
    @Setter
    @Column(name = "paciente")
    private long paciente;

    @Getter
    @Setter
    @Column(name = "medico")
    private long medico;

    @Getter
    @Setter
    @Column(name = "consultorio")
    private long consultorio;

    @Getter
    @Setter
    @Column(name = "horario")
    private Date horario;

}
