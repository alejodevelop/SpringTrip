package com.alejo.consultas.dao;

import java.util.List;

import com.alejo.consultas.models.Consultorio;

public interface IConsultorioDao {

    void registrar(Consultorio consultorio);

    List<Consultorio> obtenerConsultorios();

    Consultorio buscarConsultorio(long id);

}
