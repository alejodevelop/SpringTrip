package com.alejo.consultas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.alejo.consultas.models.Paciente;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class PacienteDaoImp implements IPacienteDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrar(Paciente paciente) {

        entityManager.merge(paciente);

    }

    @Override
    public List<Paciente> obtenerPacientes() {
        String query = "FROM Paciente";
        List<Paciente> listaPacientes = entityManager.createQuery(query).getResultList();
        return listaPacientes;
    }

    @Override
    public Paciente buscarPaciente(Long id) {
        Paciente paciente = entityManager.find(Paciente.class, id);
        return paciente;
    }

    @Override
    public void actualizarPaciente(Paciente paciente) {
        Paciente pacienteEncontrado = entityManager.find(Paciente.class, paciente.getId());
        pacienteEncontrado.setTelefono(paciente.getTelefono());
        pacienteEncontrado.setDireccion(paciente.getDireccion());
        entityManager.merge(pacienteEncontrado);
    }

}
