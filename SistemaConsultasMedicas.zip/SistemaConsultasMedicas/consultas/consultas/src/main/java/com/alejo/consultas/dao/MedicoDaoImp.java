package com.alejo.consultas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.alejo.consultas.models.Medico;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class MedicoDaoImp implements IMedicoDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrar(Medico medico) {
        entityManager.merge(medico);
    }

    @Override
    public List<Medico> obtenerMedicos() {
        String query = "FROM Medico";
        List<Medico> listaMedicos = entityManager.createQuery(query).getResultList();
        return listaMedicos;

    }

    @Override
    public Medico buscarMedico(long id) {
        Medico medico = entityManager.find(Medico.class, id);
        return medico;
    }

}
