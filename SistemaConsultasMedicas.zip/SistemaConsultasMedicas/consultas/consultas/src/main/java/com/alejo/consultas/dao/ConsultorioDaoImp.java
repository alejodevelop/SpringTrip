package com.alejo.consultas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.alejo.consultas.models.Consultorio;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class ConsultorioDaoImp implements IConsultorioDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrar(Consultorio consultorio) {
        entityManager.merge(consultorio);
    }

    @Override
    public List<Consultorio> obtenerConsultorios() {
        String query = "FROM Consultorio";
        List<Consultorio> listaConsultorios = entityManager.createQuery(query).getResultList();
        return listaConsultorios;
    }

    @Override
    public Consultorio buscarConsultorio(long id) {
        Consultorio consultorio = entityManager.find(Consultorio.class, id);
        return consultorio;
    }

}
