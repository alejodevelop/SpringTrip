package com.alejo.consultas.dao;

import com.alejo.consultas.models.Diagnostico;

public interface IDiagnosticoDao {

    void registrarDiagnostico(Diagnostico diagnostico);

}
