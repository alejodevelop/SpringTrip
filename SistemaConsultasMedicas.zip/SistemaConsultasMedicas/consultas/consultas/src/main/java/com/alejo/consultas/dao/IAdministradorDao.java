package com.alejo.consultas.dao;

import java.util.List;

import com.alejo.consultas.models.Administrador;

public interface IAdministradorDao {

    List<Administrador> validarAdministrador(Administrador administrador);
}
