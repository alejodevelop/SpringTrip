package com.alejo.consultas.dao;

import java.util.List;

import com.alejo.consultas.models.Cita;
import com.alejo.consultas.models.CitaCancelada;

public interface ICitaDao {

    void registrar(Cita cita);

    List<Cita> obtenerCitas();

    Cita eliminarCita(long id);

    void registrarCitaEliminada(CitaCancelada citaCancelada);

}
