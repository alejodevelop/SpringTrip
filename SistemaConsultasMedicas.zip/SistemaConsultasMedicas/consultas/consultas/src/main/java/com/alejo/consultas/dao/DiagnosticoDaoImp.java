package com.alejo.consultas.dao;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import com.alejo.consultas.models.Diagnostico;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class DiagnosticoDaoImp implements IDiagnosticoDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registrarDiagnostico(Diagnostico diagnostico) {

        entityManager.merge(diagnostico);

    }

}
