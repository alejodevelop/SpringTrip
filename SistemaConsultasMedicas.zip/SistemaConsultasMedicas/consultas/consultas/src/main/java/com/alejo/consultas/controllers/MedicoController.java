package com.alejo.consultas.controllers;

import java.util.List;

import com.alejo.consultas.dao.IRecetaDao;
import com.alejo.consultas.dao.IDiagnosticoDao;
import com.alejo.consultas.dao.IMedicoDao;
import com.alejo.consultas.models.Diagnostico;
import com.alejo.consultas.models.Receta;
import com.alejo.consultas.models.Medico;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MedicoController {

    @Autowired
    IRecetaDao recetaDao;

    @RequestMapping(value = "crearReceta", method = RequestMethod.POST)
    public Receta crearReceta(@RequestBody Receta receta) {
        return recetaDao.registrarReceta(receta);
    }

    @Autowired
    IDiagnosticoDao diagnosticoDao;

    @RequestMapping(value = "crearDiagnostico", method = RequestMethod.POST)
    public void crearDiagnostico(@RequestBody Diagnostico diagnostico) {

        diagnosticoDao.registrarDiagnostico(diagnostico);

    }
}
