package com.alejo.consultas.controllers;

import java.util.List;

import com.alejo.consultas.dao.IAdministradorDao;
import com.alejo.consultas.models.Administrador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {

    @Autowired
    IAdministradorDao AdministradorDao;

    @RequestMapping(value = "login", method = RequestMethod.POST)
    public List<Administrador> login(@RequestBody Administrador administrador) {

        List<Administrador> respuestaValidacion = AdministradorDao.validarAdministrador(administrador);

        return respuestaValidacion;
    }

}
