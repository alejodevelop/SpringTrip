
async function crearConsultorio() {

    datos = {};

    datos.departamento = document.getElementById("txtDepartamento").value;
    datos.municipio = document.getElementById("txtMunicipio").value;
    datos.direccion = document.getElementById("txtDireccion").value;

    const request = await fetch('crearConsultorio', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    });


    alert("El Consultorio fue creado satisfactoriamente!");


}