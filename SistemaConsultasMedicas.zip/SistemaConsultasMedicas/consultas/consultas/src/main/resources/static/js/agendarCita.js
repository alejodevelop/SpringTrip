document.addEventListener('DOMContentLoaded', function () {
    listarMedicos();
    listarPacientes();
    listarConsultorios();
}, false);

async function listar(ruta) {
    const request = await fetch(ruta, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    });

    const resultado = await request.json();
    return resultado;
}


async function listarMedicos() {

    const listaMedicos = await listar('cargarMedicos');

    console.log(listaMedicos);

    let html = '';

    for (let medico of listaMedicos) {
        let radioButtons = '<input type="radio" onChange="obtenerRadioMedico(this)" id=' + medico.id + ' name="medico">' +
            '<label for= ' + medico.id + ' > ' + medico.nombre + '  ' +
            medico.apellido + '  ' + medico.email + '  ' + '</label > <br>';

        html += radioButtons;
    }

    document.getElementById('listaMedicos').outerHTML = html;

}



async function listarPacientes() {

    const listaPacientes = await listar('cargarPacientes');

    console.log(listaPacientes);

    let html = '';

    for (let paciente of listaPacientes) {
        let radioButtons = '<input type="radio" onChange="obtenerRadioPaciente(this)" id=' + paciente.id + ' name="paciente">' +
            '<label for= ' + paciente.id + ' > ' + paciente.nombre + '  ' +
            paciente.apellido + '  ' + paciente.email + '  ' + paciente.direccion + '  ' +
            paciente.telefono + '</label > <br>';

        html += radioButtons;
    }

    document.getElementById('listaPacientes').outerHTML = html;
}

async function listarConsultorios() {
    const listaConsultorios = await listar('cargarConsultorios');

    console.log(listaConsultorios);

    let html = '';

    for (let consultorio of listaConsultorios) {
        let radioButtons = '<input type="radio" onChange="obtenerRadioConsultorio(this)" id=' +
            consultorio.id + ' name="consultorio">' +
            '<label for= ' + consultorio.departamento + ' > ' + consultorio.municipio + '  ' +
            consultorio.direccion + '</label > <br>';

        html += radioButtons;
    }

    document.getElementById('listaConsultorios').outerHTML = html;
}




datos = {};


function obtenerRadioPaciente(e) {

    datos.paciente = e.id;

}

function obtenerRadioMedico(e) {

    datos.medico = e.id;

}

function obtenerRadioConsultorio(e) {

    datos.consultorio = e.id;

}

async function generarCita() {


    datos.horario = document.getElementById('inputFechaHora').value;

    const request = await fetch('agendarCita', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    });


    alert("La cita fue creada satisfactoriamente!");

}