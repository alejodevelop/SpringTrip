
async function crearPaciente() {

    datos = {};

    datos.email = document.getElementById("txtEmail").value;
    datos.password = document.getElementById("txtPassword").value;
    datos.nombre = document.getElementById("txtNombre").value;
    datos.apellido = document.getElementById("txtApellido").value;
    datos.telefono = document.getElementById("txtTelefono").value;
    datos.direccion = document.getElementById("txtDireccion").value;


    const request = await fetch('crearPaciente', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    });


    alert("El paciente fue creado satisfactoriamente!");

}